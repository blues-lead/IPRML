# course_examples

This repository contains example code snippets used to illustrate things to my students. You are free to do
whatever you want with them.

Cheers,
Joni
